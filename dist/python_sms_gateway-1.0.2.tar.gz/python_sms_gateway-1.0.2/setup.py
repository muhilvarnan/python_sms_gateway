from setuptools import setup, find_packages

setup(name='python_sms_gateway',
      version='1.0.2',
      description='Python SMS Gateway is module used to send text sms.',
      url='https://github.com/muhilvarnan/python_sms_gateway',
      author='muhilvarnan',
      author_email='muhilvarnan.v@gmail.com',
      license='MIT',
      packages=find_packages(),
      zip_safe=False)