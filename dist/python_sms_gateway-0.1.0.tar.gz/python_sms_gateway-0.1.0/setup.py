from setuptools import setup

setup(name='python_sms_gateway',
      version='0.1.0',
      description='Python SMS Gateway is module used to send text sms.',
      url='http://github.com/storborg/funniest',
      author='muhilvarnan',
      author_email='muhilvarnan.v@gmail.com',
      license='MIT',
      packages=['python_sms_gateway'],
      zip_safe=False)
