from setuptools import setup, find_packages

setup(name='python_sms_gateway',
      version='0.1.1',
      description='Python SMS Gateway is module used to send text sms.',
      url='http://github.com/storborg/funniest',
      author='muhilvarnan',
      author_email='muhilvarnan.v@gmail.com',
      license='MIT',
      packages=find_packages(),
      zip_safe=False)
